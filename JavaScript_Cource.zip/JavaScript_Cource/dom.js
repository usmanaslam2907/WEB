console.log("Hello World")
console.log(document.dir)


// Document Object Model
// Select with ID
document.getElementById('muid');
// Select with Class
document.getElementsByClassN55ame('container')
// Select with tags
document.getElementsByTagName("div");
document.querySelector("#myid")

// append remove child
let btn1 = document.querySelector("#btn1");
btn1.onclick = () => {
    console.log("b1 clicked");

}