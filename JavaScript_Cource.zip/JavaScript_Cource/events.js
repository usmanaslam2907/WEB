// Interesting changes in events like we will register something in the broweser
// Mouse Events (click, double click);
// Keyboards evenyts(keypress, keyup,keydown)
// form events (submit)
// print event & many more
// events are created by users system warn us



//Asychronus
console.log("1");
console.log("2");
function print()
{
    console.log("Hello")
}
setTimeout(print, 4000)
console.log("3");
console.log("4");