const url = "https://google.com";
// using fetch

const getFacts = async () => {
    let promise = await fetch(url);
    console.log(promise)
}
let promise = fetch(url);
