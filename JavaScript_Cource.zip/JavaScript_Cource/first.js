// Variable in JavaScript
// null,undefined,false  dynamic variable understander datatyppe at run time;
a = 89;
let namee = "usman";
age = 23;
x = null;
namee = "khan";
console.log(namee);
console.log(age);
console.log(a + a);

//  variables names rules;
// let can not be again decleared its updated and var is again declared and updated and global scope variable let is block scope variable

// Data Types:  String , int , number , boolean , undefined , null , BigInt symbol
typeof namee;

// NULL , BigInt , Symbol is primitive , object // absense ogf 
x = BigInt("675757");
y = Symbol("hbkm");

// This above all primitive data SVGUnitTypes;

// non primitive
// arrays , functions called object categories  so non primitive collection more values so say objects(key pair values)
student = { namee: "usman" }
console.log(student['namee'].toUpperCase())

// === means match data types
// Ternary Operators
// a?b:c   if a value is true so b execute other wise c execute;     ? :

// MDN Docs



function my()
{
    console.log("myfunction")
}

my();

// arrow functions
my=()=> {
    
}

(s) => {
    console.log(s);
}

// function make  toUpperCase means method and make you own so called function if we associate object so make objects
//  forEach callback functions   ---methods are those which are associated with objects like array , strings
// functions are passed as parameters
// callback functions passed an arguments to another functions
// Array.forEach((val,id,arr) => {
//     console.log("Hello")
// })  // not used for string

// make idx

// what is higher order function  so forEach is it  that used as parameter other functions and return function as a value

//  call back functions are higher order function

array = [1, 2, 3, 4, 5, 6, 7, 8, 10];
// array.forEach((val,idx) => {
//     console.log(val * val+" and index is: "+idx);
// })

// Important Array Methods
// Map  :  map return new array   Filter and Reduce
number = array.map((val) => {
    return val;
})

// number.filter((val)=> {
//     return val % 2;
// }


