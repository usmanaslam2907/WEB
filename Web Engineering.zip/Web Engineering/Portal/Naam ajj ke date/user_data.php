
<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
//data.php
//Step-01: Data from Form

 $user_name = $_POST['user_name'];
 $user_email = $_POST['user_email'];
 $user_password = $_POST['user_password'];


$file_name = $_FILES['user_pic']['name'];
$file_tmp =  $_FILES['user_pic']['tmp_name'];


move_uploaded_file($file_tmp, 'files/'.$file_name.'.jpg');
$user_file_pic = 'files/'.$file_name.'.jpg';




 $user_password = MD5($user_password);
// Validation
if(empty($user_name)){
	$err_name = 'Name Required';
	}

else{
//Step-02: Database Connection
$host = 'localhost';
$db_user = 'root';
$db_password ='';
$db_name = 'webq4';

$db_conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if(!$db_conn){
}

//Step-03: Data Saving into table
$qry = "INSERT INTO users (user_name, user_email, user_password, user_pic) VALUES ('$user_name', '$user_email', '$user_password' , '$user_file_pic')";
$result = mysqli_query($db_conn, $qry );

header('location:user_view.php');
}
}
?>

