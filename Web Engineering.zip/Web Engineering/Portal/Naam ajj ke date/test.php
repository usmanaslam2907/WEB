<?php

$user_password = 'janu';

 $user_password_n = $user_password.'@12*7&';
 echo md5(strrev($user_password_n));

?>