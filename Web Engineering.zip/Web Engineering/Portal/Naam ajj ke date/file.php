

<html>
<body>
	<form method="post" enctype="multipart/form-data" action="file_upload.php">
	Pic: <input type="file" name="user_pic" > <br>
	<input type='submit' > <br>
	</form>
</body>
</html>
