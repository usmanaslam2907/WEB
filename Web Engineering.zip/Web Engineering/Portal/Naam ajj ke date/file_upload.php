
<?php
$file_name = $_FILES['user_pic']['name'];
$file_tmp =  $_FILES['user_pic']['tmp_name'];



echo $ext = end(explode('.', $file_name));

if($ext == 'jpg'){
	
	move_uploaded_file($file_tmp, 'files/'.$file_name);
	echo "File_Upload";
}
else{
	echo "FILE_NOT_ALLOW (ONLY JPG)";
}


?>