<?php
//Delete Data

//Step-1: Database Connection
$host = 'localhost';
$db_user = 'root';
$db_password ='';
$db_name = 'webq4';

$db_conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if(!$db_conn){
	echo 'DB_NOT_CONNECTED';
}

//Step-02: Data Delete
$id = $_GET['id'];
$qry = "DELETE FROM users WHERE user_id='$id'";
$result = mysqli_query($db_conn, $qry);

if($result){
	header('location:user_view.php');
}

?>