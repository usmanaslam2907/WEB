<?php
//data.php
//Step-01: Data from Form

 $user_name = $_POST['user_name'];
 $user_email = $_POST['user_email'];
 $user_password = $_POST['user_password'];



//Step-02: Database Connection
$host = 'localhost';
$db_user = 'root';
$db_password ='';
$db_name = 'webq4';

$db_conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if(!$db_conn){
	echo 'DB_NOT_CONNECTED';
}

//Step-03: Data Saving into table
$qry = "INSERT INTO users (user_name, user_email, user_password) VALUES ('$user_name', '$user_email', '$user_password')";
$result = mysqli_query($db_conn, $qry );


if($result){
	header('location:user_view.php');
}

?>