<?php
//Step-1: Database Connection
$host = 'localhost';
$db_user = 'root';
$db_password ='';
$db_name = 'webq4';

$db_conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if(!$db_conn){
	echo 'DB_NOT_CONNECTED';
}

//Step-02: 
echo '<table border="1"> <tr><th>ID</th><th>Pic</th><th>Name</th><th>Email</th><th>Password</th><th>Options</th></tr>';
$qry = 'SELECT * FROM users';
$data = mysqli_query($db_conn, $qry);
while($user_data = mysqli_fetch_assoc($data)){
	echo '<tr>';
	$id = $user_data['user_id'];
		echo '<td>'.$user_data['user_id'].'</td>';
		echo '<td><img src="'.$user_data['user_pic'].'" height="150px"></td>';
		echo '<td>'.$user_data['user_name'].'</td>';
		echo '<td>'.$user_data['user_email'].'</td>';
		echo '<td>'.$user_data['user_password'].'</td>';
		echo '<td><a href="user_delete.php?id='.$id.'">Delete</a></td>';

	echo '</tr>';
}
	echo '<a href="user.html">Back</a>';

?>



