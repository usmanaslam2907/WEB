<?php
$id = $_GET['id'];

// DB Connection
include('db_connection.php');

$qry = "SELECT user_name, user_email, user_password FROM users WHERE user_id='$id'";
$data = mysqli_query($db_conn, $qry);
$user_data = mysqli_fetch_assoc($data);
?>

<html>
<body>
	<form method="post" action="user_update.php"><br>
	Name:<input type='text' name='user_name' value="<?php echo $user_data['user_name']; ?>"> <br>
	Email:<input type='email' name='user_email' value="<?php echo $user_data['user_email']; ?>"> <br>
	Password:<input type='password' name='user_password' value="<?php echo $id; ?>"> <br>
	<input type="text" name="id" value="<?php echo $id; ?>" hidden>
	<input type='submit' value="Update Data"> <br>
	</form>
</body>
</html>

