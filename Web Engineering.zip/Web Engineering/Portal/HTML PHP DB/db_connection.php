<?php

$host = 'localhost';
$db_user = 'root';
$db_password ='';
$db_name = 'webq4';

$db_conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if($db_conn){
	echo 'DB_CONNECTED';
}

?>