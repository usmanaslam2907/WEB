<?php

//DB Connection
include('db_connection.php');

$id = $_GET['id'] ;
$qry = 'DELETE FROM users WHERE user_id='.$id.'';
if(mysqli_query($db_conn, $qry))
{
	header('location:user_view.php');
}
else{
	echo 'ERROR:: ',mysqli_error($db_conn);
}

?>