<?php
//data.php
//Step-01: Data from Form

 $user_id = $_POST['user_id'];
 $user_name = $_POST['user_name'];
 $user_email = $_POST['user_email'];
 $user_password = $_POST['user_password'];
 
 $file_tmp = $_FILES['user_pic']['tmp_name'];
 $file_name = $_FILES['user_pic']['name'];
 $user_pic = 'files/'.$file_name;
	
$ext = end(explode('.',$file_name));
if($ext =='png' || $ext =='jpg'){
	

 move_uploaded_file($file_tmp , $user_pic  );



$user_password = MD5($user_password);

//Step-02: Database Connection
$host = 'localhost';
$db_user = 'root';
$db_password ='';
$db_name = 'webq4';

$db_conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if($db_conn){
	echo 'DB_CONNECTED';
}

//Step-03: Data Saving into table

$result = mysqli_query($db_conn, "INSERT INTO users (user_id, user_name, user_email, user_password, user_pic) VALUES ('$user_id', '$user_name', '$user_email', '$user_password', '$user_pic')");

if($result){
header('location:user_view.php');
}
else{
		echo mysqli_error($db_conn);
}

}
else{
	echo 'file_not_allow';
}



?>