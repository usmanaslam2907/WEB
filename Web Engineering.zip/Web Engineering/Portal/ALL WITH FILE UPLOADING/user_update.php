<?php

$user_id = $_POST['id'];
$user_name = $_POST['user_name'];
$user_email = $_POST['user_email'];
$user_password = $_POST['user_password'];
$user_password = MD5($user_password);

//Step-01: Database Connection
include('db_connection.php');

//Step-02: Update Database

$qry = "UPDATE users SET user_name='$user_name', user_email='$user_email', user_password='$user_password' WHERE user_id='$user_id'";

$result = mysqli_query($db_conn, $qry);
if($result){
	header('location:user_view.php');
	}
	else{
		echo mysqli_error($db_conn);
	}
	?>