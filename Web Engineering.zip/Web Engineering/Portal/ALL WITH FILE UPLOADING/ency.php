<?php

$pass = 'janu';
echo md5($pass);


?>