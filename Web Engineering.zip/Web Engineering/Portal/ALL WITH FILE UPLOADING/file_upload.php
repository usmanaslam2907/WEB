<?php

$file_name = $_FILES['user_pic']['name'];
$file_tmp = $_FILES['user_pic']['tmp_name'];

//Filter

$ext = end(explode('.' , $file_name));

if( $ext =='png'){	
move_uploaded_file($file_tmp , 'files/'.$file_name  );
}
else{
	echo 'Extension Not Allow';
}
?>