<?php

//Step-01: DB Connection
include('db_connection.php');

//Step-02: View Data

$data = mysqli_query($db_conn, 'SELECT * FROM users');

?>



<html>
	<body>
		<table border="1">
			<?php 
			while($user_data =(mysqli_fetch_assoc($data)))
			{
				echo '<tr>';
				$id = $user_data['user_id'];
					echo '<td>'.$user_data['user_id'].'</td>';
					echo '<td><img src="'.$user_data['user_pic'].'" height="100px"></td>';
					echo '<td>'.$user_data['user_name'].'</td>';
					echo '<td>'.$user_data['user_email'].'</td>';
					echo '<td>'.$user_data['user_password'].'</td>';
					echo '<td><a href="user_delete.php?id='.$id.'">Delete </a></td>';
					echo '<td><a href="user_update_form.php?id='.$id.'"> Update</a></td>';
				echo '</tr>';
			}?>
		</table>
		<a href="user_form.html">User From</a>
	</body>
</html>

