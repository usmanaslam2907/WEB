

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone="+00:00";
$employee_name=$_POST['employee_name'];
$employee_country=$_POST['employee_country'];
$employee_email=$_POST['employee_email'];
$employee_password=$_POST['employee_password'];
$employee_repassword=$_POST['employee_repassword'];

create table `employee`(
    `name` varchar(50) NOT NULL,
    `email` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    `repassword` varchar(50) NOT NULL,
    `country` varchar(50) NOT NULL,
    `gender` char NOT NULL,
    `birthdate` date NOT NULL,
    `image` binary NOT NULL

)
ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- INSERT INTO `employee` (`name`, `country`, `email`,`password`,`repassword`,`image`,`birthdate`,`gender`) VALUES ('$employee_name','$employee_country', '$employee_email','$employee_password','$employee_repassword','$image','$birthdate','$gender');COMMIT;

