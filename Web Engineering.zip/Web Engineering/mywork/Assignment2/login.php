<!doctype html>
<html>

<head>


    <script src="https://kit.fontawesome.com/9e057334c3.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="login.css">
    <title>Employee Login</title>
    </style>
</head>

<body>

    <h1 class="main">Employee Management System</h1>
    <div class="container">
        <form method="POST" action="login.php">
            <h1>Login</h1>
            <div class="box">
                <input type="email" name="Email" id="email" placeholder="     Enter email">
            </div>
            <div class="box">
                <input type="password" name="password" id="password" placeholder="     Enter password">
            </div>

            <div class="button">
                <button type="submit" name="login" class="btn" ><a href="displaycv.php">Login</a></button>
                <button class="btn">Forget?</button>
            </div>
            <p style="margin-top:23px; margin-left:14px;"
   
>
                Not yet a memeber? <a style="color:#25dede;text-decoration:none;"href="registration.php">Sign up</a>
            </p>

        </form>
    </div>


</body>

</html>