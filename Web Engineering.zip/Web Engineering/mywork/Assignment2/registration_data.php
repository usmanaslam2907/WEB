<?php

// session_start();
 $employee_name = $_POST['employee_name'];
$employee_country = $_POST['country'];
$employee_email = $_POST['employee_email'];
$employee_password = $_POST['employee_password'];
$employee_repassword = $_POST['employee_repassword'];
$image = $_POST['employee_image'];
$birthdate = $_POST['date'];
$gender = $_POST['gender'];
$errors=array();

// if($employee_password!=$employee_repassword)
// {
//     array_push($errors,"Both password must be same.");

 
// }

include('db_connection.php');



if(count($errors)==0)
{
    $employee_password=md5($employee_password);
    $result = mysqli_query($db_conn, "INSERT INTO `employee` (`name`,`country`, `email`, `password`, `repassword`,`image`,`birthdate`,`gender`) VALUES ('$employee_name', '$employee_country', '$employee_email', '$employee_password','$employee_repassword','$image','$birthdate','$gender')");
    // $_SESSION['employee_name']=$employee_name;
    // $_SESSION['success']="You are logged in here";
  
    header('location:cvform.php');
    

}
