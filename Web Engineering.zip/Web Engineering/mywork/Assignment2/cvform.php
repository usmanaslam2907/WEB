<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UCP Admission Form</title>
    <style>
        * {
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        td {
            padding: 5px;
        }

        table {
            background-color: rgba(128, 128, 128, 0.082);
        }

        input {
            outline: none;
            padding: 8px;
            width: 96%;
        }

        button[type="submit"] {
            background-color: rgba(0, 255, 255, 0.637);
            font-size: larger;
            width: 21%;
            border-radius: 8px;
            outline: none;
            margin-top: 4px;
            cursor: pointer;
        }

        th {
            background-color: rgba(0, 255, 255, 0.637);
            color: rgba(0, 0, 0, 0.719);
        }
    </style>
</head>

<body>
    <table border="1" align="center" width="90%">
        <thead>
            <tr>
                <th colspan="2">
                    <font size="8px"> Data Collection of Employee </font>
                </th>
            </tr>
        </thead>
        <tbody>
        <form method="POST" action=cv_data.php>
            <tr>
                <td><label>Employee Name</label></td>
                <td colspan="2"><input type="text" name="fullname" placeholder="Enter full name" required></td>
            </tr>
            <tr>
                <td><label> Mobile No.</label></td>
                <td><input type="number" name="number" placeholder="Enter mobile no." required></td>
            </tr>
            <tr>
                <td><label>Address</label></td>
                <td><input type="text" name="address" placeholder="Enter address" required></td>
            </tr>
            <tr>
                <td><label>E-mail</label></td>
                <td><input type="email" name="email" placeholder="Enter email" required></td>
            </tr>
            <tr>
                <td><label>Vision</label></td>
                <td><input type="text" name="goals" placeholder="Enter your vision" required></td>
            </tr>
            <tr>
                <td><label>CNIC/B-Form No</label></td>
                <td><input type="number" name="cnic" placeholder="Enter CNIC/B-Form" required></td>
            </tr>
            <tr>
                <td><label>Date of Birth</label></td>
                <td><input type="date" name="dob" placeholder="Enter date of birth" required></td>
            </tr>
            <tr>
                <td colspan="2"><label>Select profile</label><input type="file" name="profile" required></td>
            </tr>

            <tr>
                <th colspan="2" align="center"><label>Education</label><br>
            </tr>


            <tr>
                <td colspan="2">
                    Matric:<input type="checkbox" name="education" value="Matric" class="width">

                    Intermediate: <input type="checkbox" name="education" value="Intermediate" class="width">

                    Graduate: <input type="checkbox" name="education" value="Graduate" class="width">

                    Masters <input type="checkbox" name="education" value="Master" class="width">

                </td>
            </tr>
            <tr>
                <th colspan="2" align="center"><label>Attached Scan files of your documents</label><br>
            </tr>
            <tr>
                <td colspan="2">
                    <label>Matric Degree</label><input type="file" name="matric" required>
                    <label>Intermediate Degree</label><input type="file" name="intermediate" required>
                    <label>Graduate Degree</label><input type="file" name="graduate" required>
                    <label>Master Degree</label><input type="file" name="master" required>
                </td>
            </tr>
            <tr>
                <td><label>Work Experience</label></td>
                <td><input type="number" name="experience" placeholder="Enter your Work-experience (year)" required>
                </td>
            </tr>
            <tr>
                <th colspan="2"><label>Skills</label></th>
            <tr>

                <td colspan="2"><input type="text" name="skill1" placeholder="Enter Skill#1" required></td>
            </tr>
            <tr>

                <td colspan="2"><input type="text" name="skill2" placeholder="Enter Skill#2" required></td>
            </tr>
            <tr>

                <td colspan="2"><input type="text" name="skill3" placeholder="Enter Skill#3" required></td>
            </tr>
            <tr>

                <td colspan="2"><input type="text" name="skill4" placeholder="Enter Skill#4" required></td>
            </tr>
            <tr>

                <td colspan="2"><input type="text" name="skill5" placeholder="Enter Skill#5" required></td>
            </tr>
            </tr>
            <tr>
                <th colspan="2"><label>Hobbies</label></th>
            <tr>

                <td colspan="2"><input type="text" name="hobby1" placeholder="Enter hobby#1" required></td>
            </tr>
            <tr>

                <td colspan="2"><input type="text" name="hobby2" placeholder="Enter hobby#2" required></td>
            </tr>
            <tr>

                <td colspan="2"><input type="text" name="hobby3" placeholder="Enter hobby#3" required></td>
            </tr>
            <tr>

                <td colspan="2"><input type="text" name="hobby4" placeholder="Enter hobby#4" required></td>
            </tr>
            <tr>
                <th colspan="2"><label>Personal Information</label></th>
            <tr>
            <tr>
                <td><label>Father Name</label></td>
                <td colspan="2"><input type="text" name="fathername" placeholder="Enter father name" required></td>
            </tr>
            <tr>
                <td><label>Gender</label></td>
                <td colspan="2">
                    <select name="gender">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Transgender">Transgender</option>
                    </select>

                </td>
            </tr>
            <tr>
                <td><label>Nationality</label></td>
                <td colspan="2"><input type="text" name="nationality" placeholder="Enter Nationality" required></td>
            </tr>
            <tr>
                <td><label>Religion</label></td>
                <td colspan="2"><input type="text" name="religion" placeholder="Enter religion" required></td>
            </tr>
            <tr>
                <td><label>Martial Status</label></td>
                <td colspan="2">
                    <select name="marry">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>

                </td>
            </tr>
            <tr>
                <td colspan="2" align="center"><button type="submit">Save</button></td>
            </tr>
            </tbody>
            </form>

    </table>
</body>

</html>