<?php



$host = 'localhost';
$db_user = 'root';
$db_password ='';
$db_name = 'resume';

$db_conne = mysqli_connect($host, $db_user, $db_password, $db_name);

if($db_conne){
	echo 'DB_CONNECTED';
}

?>
