<?php

session_start();
include('db_connectioncv.php');
 $r_name = $_POST['fullname'];
 $r_number = $_POST['number'];
 $r_address = $_POST['address'];
 $r_email = $_POST['email'];
 $r_vision = $_POST['goals'];
 $r_cnic = $_POST['cnic'];
 $r_date = $_POST['dob'];
 $r_profile = $_POST['profile'];

//  education
 $r_education = $_POST['education'];
 $r_matric = $_POST['matric'];
 $r_intermediate = $_POST['intermediate'];
 $r_graduate = $_POST['graduate'];
 $r_master = $_POST['master'];
 $r_experience = $_POST['experience'];
// skills
$r_skill1 = $_POST['skill1'];
$r_skill2 = $_POST['skill2'];
$r_skill3 = $_POST['skill3'];
$r_skill4 = $_POST['skill4'];
$r_skill5 = $_POST['skill5'];

// hobbies
$r_hobby1 = $_POST['hobby1'];
$r_hobby2 = $_POST['hobby2'];
$r_hobby3 = $_POST['hobby3'];
$r_hobby4 = $_POST['hobby4'];


// personal information
$r_fathername = $_POST['fathername'];
$r_gender = $_POST['gender'];
$r_nationality = $_POST['nationality'];
$r_religion = $_POST['religion'];
$r_marry = $_POST['marry'];


$qry = "INSERT INTO `cv` (`Name`, `Phone`, `Address`, `Email`, `Vision`, `CNIC`, `Date`, `Profile`, `Education`, `Matric`, `Intermediate`, `Graduate`, `Master`, `Experience`, `Skill#1`, `Skill#2`, `Skill#3`, `Skill#4`, `Skill#5`, `Hobby#1`, `Hobby#2`, `Hobby#3`, `Hobby#4`, `Father Name`, `Gender`, `Nationality`, `Religion`, `Marry`) VALUES ('$r_name', '$r_number', '$r_address', '$r_email', '$r_vision', '$r_cnic', '$r_date', '$r_profile', '$r_education', '$r_matric', '$r_intermediate', '$r_graduate', '$r_master', '$r_experience', '$r_skill1', '$r_skill2', '$r_skill3', '$r_skill4', '$r_skill5', '$r_hobby1', '$r_hobby2', '$r_hobby3', '$r_hobby4', '$r_fathername', '$r_gender','$r_nationality','$r_religion','$r_marry')";

$r_data = mysqli_query($db_conne, $qry);
if($r_data){
	header('location:displaycv.php');
    echo "success";
	}
	else{
		echo mysqli_error($db_conne);
	}
	?>







    


