SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone="+00:00";


create table `cv`
(

`Name` varchar(100),
`Email` varchar(100),
`Phone` int(100),
`Address` varchar(100),
`Vision` varchar(100),
`CNIC` varchar(100),
`Date` date,
`Profile` varchar(100),


-- //Education
`Education` varchar(100),
`Matric` varchar(100),
`Intermediate` varchar(100),
`Graduate` varchar(100),
`Master` varchar(100),
`Experience` int,


-- Skills
`Skill#1` varchar(100),
`Skill#2` varchar(100),
`Skill#3` varchar(100),
`Skill#4` varchar(100),
`Skill#5` varchar(100),

-- Hobbies
`Hobby#1` varchar(100),
`Hobby#2` varchar(100),
`Hobby#3` varchar(100),
`Hobby#4` varchar(100),

-- Personal Information
`Father Name` varchar(100),
`Gender` varchar(100),
`Nationality` varchar(100),
`Religion` varchar(100),
`Marry` varchar(100),





) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `cv` (`Name`, `Phone`, `Address`, `Email`, `Vision`, `CNIC`, `Date`, `Profile`, `Education`, `Matric`, `Intermediate`, `Graduate`, `Master`, `Experience`, `Skill#1`, `Skill#2`, `Skill#3`, `Skill#4`, `Skill#5`, `Hobby#1`, `Hobby#2`, `Hobby#3`, `Hobby#4`, `Father Name`, `Gender`, `Nationality`, `Religion`, `Marry`) VALUES ('$Name', '0342000000', 'E-------', 'usman@gmail.com', 'Working', '2352', '2021-12-08', 'etgq4ty3gr', 'graduate', 'dsvsdv', 'gwergeweew', 'ewwe', 'eahneaht', '45', 'erhae', 'erheahea', 'earh', 'rewahaewr', 'rehaewrh', '', 'erahaw', 'earhaewr', 'arehareh', 'erheraherh', 'Male', 'aerhaewh', 'rweahewarh', '')COMMIT;
