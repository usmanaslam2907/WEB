<?php
include('db_connectioncv.php');



$view = mysqli_query($db_conne, 'SELECT * FROM cv');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        table {
            background-color: rgba(128, 128, 128, 0.068);
        }

        * {
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        th {
            background-color: aqua;
        }

        td {
            padding: 5px;
        }
    </style>
    <title>Resume</title>
</head>

<body>
    <table border="1" width="80%" align="center">
        <?php

        while ($employee_data = (mysqli_fetch_assoc($view))) {


            //Info
            echo '<tr>';
            echo '<td colspan="2" align="center"><img src="' . $employee_data['Profile'] . '" alt="Loading" width="180" height="180"></td>';
            echo '</tr>';
            echo '<tr align="center">';
            echo '<td colspan="2">' . $employee_data['Name'] . '</td>';
            echo '</tr>';
            echo '<tr align="center">';
            echo '<td colspan="2">' . $employee_data['Address'] . '</td>';
            echo '</tr>';
            echo '<tr align="center">';
            echo '<td colspan="2">' . $employee_data['Phone'] . '</td>';
            echo '</tr>';
            echo '<tr align="center">';
            echo '<td colspan="2">' . $employee_data['Email'] . '</td>';
            echo '</tr>';

            // Vision
            echo '<tr>';
            echo '<th colspan="5">';
            echo "Objective";
            '</th>';
            echo ' </tr>';
            echo '<tr align="center">';
            echo ' <td colspan="2">' . $employee_data['Vision'] . '</td>';
            echo '</tr>';


            // Education
            echo '<th colspan="5">';
            echo "Education";
            '</th>';
            echo '<tr align="center">';
            echo ' <td colspan="2">' . $employee_data['Education'] . '</td>';
            echo '</tr>';


            // Skills
            echo '<th colspan="5">';
            echo "Skills";
            '</th>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Skill#1'] . '</td>';
            echo ' </tr>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Skill#2'] . '</td>';
            echo ' </tr>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Skill#3'] . '</td>';
            echo ' </tr>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Skill#3'] . '</td>';
            echo ' </tr>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Skill#5'] . '</td>';
            echo ' </tr>';

            //  Experience
            echo '<th colspan="5">';
            echo "Work Experience";
            '</th>';
            echo '<tr align="center">';
            echo ' <td colspan="2">' . $employee_data['Experience'] . '  Years</td>';
            echo '</tr>';




            //Hobbies
            echo '<th colspan="5">';
            echo "Hobbies";
            '</th>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Hobby#1'] . '</td>';
            echo ' </tr>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Hobby#2'] . '</td>';
            echo ' </tr>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Hobby#3'] . '</td>';
            echo ' </tr>';
            echo '<tr>';
            echo '<td colspan="2">' . $employee_data['Hobby#3'] . '</td>';
            echo ' </tr>';
          

            // Personal Information
            echo '<th colspan="5">';
            echo "Personal Information";
            '</th>';


            echo '<tr>';
            echo '<td>';
            echo "Father Name";
            '</td>';
            echo '<td>' . $employee_data['Father Name'] . '</td>';
            echo '</tr>';


            echo '<tr>';
            echo '<td>';
            echo "Date of Birth";
            '</td>';
            echo '<td>' . $employee_data['Date'] . '</td>';
            echo '</tr>';


            echo '<tr>';
            echo '<td>';
            echo "Gender";
            '</td>';
            echo '<td>' . $employee_data['Gender'] . '</td>';
            echo '</tr>';


            echo '</tr>';
            echo '<td>';
            echo "Nationality";
            '</td>';
            echo '<td>' . $employee_data['Nationality'] . '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td>';
            echo "Religion";
            '</td>';
            echo '<td>' . $employee_data['Religion'] . '</td>';
            echo '</tr>';
        }


        echo '<th colspan="5">';
        echo "Thanks for your response";
        '</th>';

        echo '<tr>';
        echo '<td align="center">';
        echo  '<button  type="reset" value="Clear" name="clear">';echo "Clear"; '</button>';
        echo   '</td>';
        echo '<td align="center">';
        echo  '<button   value="Update" name="update">';echo '<a href="cvform.php">';echo "Update";'</button>';
        echo   '</td>';
        echo  '</tr>'
        ?>

    </table>

</body>

</html>