<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}



?>



<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Videos</title>
    <style>
        :root {
            --col: purple;
        }

        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        html {
            font-size: 30px;

        }


        .container .heading {
            text-align: center;
            font-size: 1rem;
            text-transform: capitalize;
            color: var(--col);
            font-family: UI-SANS-SERIF;
        }

        .container .video-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;



        }

        .container .video-container .video {

            height: 6rem;
            width: 10rem;
            overflow: hidden;
            margin: 0.5rem;
            box-shadow: 0 0.1rem 0.4rem grey;
            border-radius: 0rem;
        }

        .container .video-container .video video {
            object-fit: cover;
            height: 100%;
            width: 100%;
            cursor: pointer;
            border: none;
            outline: none;
        }

        .container .video-container .video video:hover {
            transition: 0.5s linear;
            transform: scale(1.4);
        }

        .container .video-container .video .active {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            height: auto;
            width: 80%;
            z-index: 1;
        }

        .container .video-container .video .active:hover {
            transition: none;
            transform: translate(-50%, -50%) scale(1);
        }

        .title {
            font-size: 14px;
            font-family: sans-serif;
            padding: 0px;
            margin-left: 17px;
        }

        .btn a {
            text-decoration: none;
        }

        .btn {
            width: 104px;
            height: 30px;
            float: right;
            margin-right: 32px;
            background: #aac4f3;
            outline: none;
            border: 1px solid blue;
            border-radius: 25px;


        }

        .btn:hover {
            background: #4cbf4c;
        }

        .uploader {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 55%;
            /* border:2px solid #80808021; */
            margin-top: 20px;
            background-color: #80808021;
        }

        .upload_text {
            font-size: 20px;
            font-family: sans-serif;
        }

        .upload_btn {
            padding: 10px 43px;
            border: 1px solid #6e4444;
            border-radius: 3px;
            font-size: 19px;
            color: white;
            background-color: #0000ff73;
            display: block;
            width: 13%;
            position: absolute;
            margin-top: 8%;
        }
        .upload_btn a {
         text-decoration:none;
         color:white;
        }

        .upload_btn:hover {
            background: #02ff02a3;
            cursor: pointer;
        }
    </style>
</head>

<body>

    <button class="btn"><a href="logout.php">Logout</a></button>
    <div class="uploader">
        <p class="upload_text">Upload a youtube video ! Click Upload</p>
        <button class="upload_btn"><a href="upload.php">Upload</a></button>
    </div>
    <div class="container">
        <h1 class="heading">Video Gallery</h1>
        <div class="video-container">
<?php
        include("uTubeconnection.php");

			$q = "SELECT * FROM video";

			$query = mysqli_query($conn, $q);

			while ($row = mysqli_fetch_array($query)) {

				$name = $row['name'];
                $title=$row['title'];
            ?>
            <div>
                <div class="video">
                    <video src="<?php echo 'upload/' . $name; ?>" controls></video>
                </div>
                <div class="video_title">
                    <p class="title"><?php echo $title; ?></p>
                </div>
            </div>
<?php
            }
?>
        </div>

        <script>
            let videolist = document.querySelectorAll('.video-container video');
            let mainvideo = document.querySelector('.mainvideo .video');
            let title = document.querySelector('.mainvideo .title');

            videolist.forEach(video => {
                video.onclick = () => {
                    videolist.forEach(vid => vid.classList.remove('active'));
                    video.classList.add('active');
                    if (video.classList.contains('active')) {
                        let src = video.children[0].getAttribute('src');
                        mainvideo.src = src;
                        let text = video.children[1].innerHTML;
                        title.innerHTML = text;
                    }
                }
            });
        </script>
</body>

</html>