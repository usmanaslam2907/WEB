<?php

include("uTubeconnection.php");
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}




  if (isset($_POST['upload'])) 
  {
      
    echo "<script>alert('Uploading Video...')</script>";
    $file_title=$_POST['title'];
    $file_name = $_FILES['file']['name'];
    $file_type = $_FILES['file']['type'];	
    $temp_name = $_FILES['file']['tmp_name'];
    $file_size = $_FILES['file']['size'];
    $allowed_extensions = array("mp4");
    $file_name_temp = explode(".", $file_name);
    $extension = end($file_name_temp);
    if(str_word_count($file_title)<5)
    {
        echo "<script>alert('Please enter title atleast 5 words! Thanks')</script>";
    }
    else
    {
      
        if (($file_type == "video/mp4") &&in_array($extension, $allowed_extensions))
        {
               
      $file_destination = "upload/".$file_name;
  
      if (move_uploaded_file($temp_name,$file_destination))
       { 
      
      $q = "INSERT INTO video (`name`,`title`) VALUES ('$file_name','$file_title')";
       }
      if(mysqli_query($conn,$q))
       {
  
        echo "<script>alert('Video is successfully Uploaded! Thanks.')</script>";
      }
      else {
          
        echo "<script>alert('Video is not  Uploaded! Please try again.')</script>";
      }
        }
        else{
            echo "<script>alert('Inavlid format ! Please try again MP4 format.')</script>";
        }
    

      
    }
  }
  else {
  
    echo "<script>alert('Please Select  a Video! Thanks')</script>";
  }
  


?>



<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uploading Video......</title>
    <style>
        :root {
            --col: purple;
        }

        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        html {
            font-size: 30px;

        }
     
        .btn {
            width: 104px;
            height: 30px;
            float: right;
            margin-right: 32px;
            background: #aac4f3;
            outline: none;
            border: 1px solid blue;
            border-radius: 25px;
        }
        .upload_text {
            font-size: 20px;
            font-family: sans-serif;
        }
        .container{
            width: 100%;
    height: 55%;
    border: 2px solid #80808021;
    margin-top: 20px;
    background-color: #80808021;
    display: flex;
    justify-content: center;
    align-items: center;
        }
        .upload_btn {
            padding: 7px 25px;
    border: 1px solid #6e4444;
    border-radius: 3px;
    font-size: 20px;
    color: white;
    background-color: #0000ff73;
    display: block;
    width: 39%;
    margin-top:25px;
           
        }

        .upload_btn:hover {
            background: #02ff02a3;
            cursor: pointer;
        }
        .view_btn:hover {
            background: #02ff02a3;
            cursor: pointer;
        }
       
      .view_btn 
           {
            padding: 9px 25px;
    border: 1px solid #6e4444;
    border-radius: 3px;
    font-size: 18px;
    color: white;
    background-color: #0000ff73;
    display: block;
    width: 39%;
    margin-top: 25px
           }
      .view_btn a
           {
           text-decoration:none;
           color:white;
           }
           input{
         padding:4px 0px;
           }
        .title
        {border: 1px solid #2a9d0d;
    font-size: 17px;
    font-family: sans-serif;
    color: white;
    background: #33bd30;
    padding: 1px 13px;
        }
        .title:hover
        {
            background: green;
        }
      
    </style>
</head>

<body>

    <button class="btn"><a href="logout.php">Logout</a></button>
    <div class="container">
        <div class="uploader">
        <div>
               <p class="upload_text"> Upload a Youtube Video here! Click Upload.</p>
        </div>
        <div>
            <form action="upload.php" method="post" enctype="multipart/form-data" >
            <input type="file"  name="file">
            <label class="title">Title</label>
            <input type="text" name="title" placeholder="Enter the title here">
          <input type="submit" name="upload" value="Upload" class="upload_btn">
          <button class="view_btn"><a href=welcome.php>View Videos</a></button>
    </form>
   
        </div>
    </div>
    </div>


</body>

</html>