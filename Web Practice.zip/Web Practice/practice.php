<?php
//what is the sessions
// used to manage onformation across difference pages
// Verification
session_start();
$_SESSION['username']="Harry";
$_SESSION['favourite']="BOOKS";





?>