﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace RegistrationSystem
{
    public partial class Form1 : Form
    {
        string constr = @"Data Source=DESKTOP-4DSKRH6;Initial Catalog=Registration;Integrated Security=true";
        SqlConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection(constr);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4DSKRH6;Initial Catalog=Registration;Integrated Security=True");
            string query=@"INSERT INTO [dbo].[Regis]
           ([firstname]
           ,[lastname]
           ,[address]
           ,[gender]
           ,[email]
           ,[phone]
           ,[username]
           ,[password])
     VALUES
           ('"+txtfname.Text+"','"+txtlname.Text+"','"+txtaddress.Text+"','"+cbgender+"','"+txtemail.Text+"','"+txtphone.Text+"','"+txtuser.Text+"','"+txtpassword.Text+"')";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Register Successfully");
            con.Close();

           
            
            
        }
    }
}
